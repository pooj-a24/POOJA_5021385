// BuilderPatternExample.java
public class BuilderPatternExample {

    // Product Class: Computer
    public static class Computer {
        private final String CPU;
        private final int RAM;
        private final int Storage;
        private final boolean hasGraphicsCard;
        private final boolean hasBluetooth;

        // Private constructor
        private Computer(Builder builder) {
            this.CPU = builder.CPU;
            this.RAM = builder.RAM;
            this.Storage = builder.Storage;
            this.hasGraphicsCard = builder.hasGraphicsCard;
            this.hasBluetooth = builder.hasBluetooth;
        }

        @Override
        public String toString() {
            return "Computer [CPU=" + CPU + ", RAM=" + RAM + "GB, Storage=" + Storage + "GB, " +
                   "GraphicsCard=" + (hasGraphicsCard ? "Yes" : "No") + ", Bluetooth=" + (hasBluetooth ? "Yes" : "No") + "]";
        }

        // Static Nested Builder Class
        public static class Builder {
            private String CPU;
            private int RAM;
            private int Storage;
            private boolean hasGraphicsCard;
            private boolean hasBluetooth;

            public Builder setCPU(String CPU) {
                this.CPU = CPU;
                return this;
            }

            public Builder setRAM(int RAM) {
                this.RAM = RAM;
                return this;
            }

            public Builder setStorage(int Storage) {
                this.Storage = Storage;
                return this;
            }

            public Builder setGraphicsCard(boolean hasGraphicsCard) {
                this.hasGraphicsCard = hasGraphicsCard;
                return this;
            }

            public Builder setBluetooth(boolean hasBluetooth) {
                this.hasBluetooth = hasBluetooth;
                return this;
            }

            public Computer build() {
                return new Computer(this);
            }
        }
    }

    // Test Class to demonstrate the Builder pattern
    public static void main(String[] args) {
        // Create different configurations of Computer using Builder pattern
        Computer computer1 = new Computer.Builder()
                .setCPU("Intel i7")
                .setRAM(16)
                .setStorage(512)
                .setGraphicsCard(true)
                .setBluetooth(true)
                .build();

        Computer computer2 = new Computer.Builder()
                .setCPU("AMD Ryzen 5")
                .setRAM(8)
                .setStorage(256)
                .build();

        System.out.println("Computer 1: " + computer1);
        System.out.println("Computer 2: " + computer2);
    }
}
