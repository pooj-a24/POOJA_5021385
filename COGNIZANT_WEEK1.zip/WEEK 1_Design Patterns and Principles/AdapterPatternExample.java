// AdapterPatternExample.java
public class AdapterPatternExample {

    // Target Interface
    public interface PaymentProcessor {
        void processPayment(double amount);
    }

    // Adaptee Classes
    public static class PayPalPayment {
        public void payWithPayPal(double amount) {
            System.out.println("Processing payment with PayPal: $" + amount);
        }
    }

    public static class StripePayment {
        public void chargeWithStripe(double amount) {
            System.out.println("Processing payment with Stripe: $" + amount);
        }
    }

    // Adapter for PayPal
    public static class PayPalAdapter implements PaymentProcessor {
        private PayPalPayment payPalPayment;

        public PayPalAdapter(PayPalPayment payPalPayment) {
            this.payPalPayment = payPalPayment;
        }

        @Override
        public void processPayment(double amount) {
            payPalPayment.payWithPayPal(amount);
        }
    }

    // Adapter for Stripe
    public static class StripeAdapter implements PaymentProcessor {
        private StripePayment stripePayment;

        public StripeAdapter(StripePayment stripePayment) {
            this.stripePayment = stripePayment;
        }

        @Override
        public void processPayment(double amount) {
            stripePayment.chargeWithStripe(amount);
        }
    }

    // Test Class to demonstrate the Adapter Pattern
    public static void main(String[] args) {
        // Create instances of payment gateways
        PayPalPayment payPalPayment = new PayPalPayment();
        StripePayment stripePayment = new StripePayment();

        // Create adapters for payment gateways
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPayment);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripePayment);

        // Process payments using adapters
        payPalAdapter.processPayment(100.00);
        stripeAdapter.processPayment(200.00);
    }
}
