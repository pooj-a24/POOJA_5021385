// Define the Notifier interface
interface Notifier {
    void send(String message);
}

// Implement the Concrete Component EmailNotifier
class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("Sending Email: " + message);
    }
}

// Implement the abstract Decorator class NotifierDecorator
abstract class NotifierDecorator implements Notifier {
    protected Notifier wrappedNotifier;

    public NotifierDecorator(Notifier notifier) {
        this.wrappedNotifier = notifier;
    }

    @Override
    public void send(String message) {
        wrappedNotifier.send(message);
    }
}

// Implement the Concrete Decorator SMSNotifierDecorator
class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending SMS: " + message);
    }
}

// Implement the Concrete Decorator SlackNotifierDecorator
class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending Slack message: " + message);
    }
}

// Test the Decorator Pattern Implementation
public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Sending notification through Email:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nSending notification through Email and SMS:");
        smsAndEmailNotifier.send("Hello via Email and SMS!");

        System.out.println("\nSending notification through Email, SMS, and Slack:");
        slackAndSmsAndEmailNotifier.send("Hello via Email, SMS, and Slack!");
    }
}
