// ProxyPatternExample.java
public class ProxyPatternExample {

    // Subject Interface
    public interface Image {
        void display();
    }

    // Real Subject Class
    public static class RealImage implements Image {
        private String filename;

        public RealImage(String filename) {
            this.filename = filename;
            loadFromServer();
        }

        private void loadFromServer() {
            System.out.println("Loading image: " + filename);
        }

        @Override
        public void display() {
            System.out.println("Displaying image: " + filename);
        }
    }

    // Proxy Class
    public static class ProxyImage implements Image {
        private RealImage realImage;
        private String filename;

        public ProxyImage(String filename) {
            this.filename = filename;
        }

        @Override
        public void display() {
            if (realImage == null) {
                realImage = new RealImage(filename); // Lazy initialization
            }
            realImage.display(); // Display the image
        }
    }

    // Test Class
    public static void main(String[] args) {
        Image image1 = new ProxyImage("image1.jpg");
        Image image2 = new ProxyImage("image2.jpg");

        // Image will be loaded and displayed on the first access
        image1.display();
        System.out.println();

        // Image will be displayed directly as it's already loaded
        image1.display();
        System.out.println();

        // Image will be loaded and displayed on the first access
        image2.display();
    }
}
