// CommandPatternExample.java

// Command Interface
interface Command {
    void execute();
}

// Receiver Class
class Light {
    public void turnOn() {
        System.out.println("Light is ON");
    }

    public void turnOff() {
        System.out.println("Light is OFF");
    }
}

// Concrete Command Class - LightOnCommand
class LightOnCommand implements Command {
    private Light light;

    public LightOnCommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOn();
    }
}

// Concrete Command Class - LightOffCommand
class LightOffCommand implements Command {
    private Light light;

    public LightOffCommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOff();
    }
}

// Invoker Class - RemoteControl
class RemoteControl {
    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void pressButton() {
        command.execute();
    }
}

// Test Class
public class CommandPatternExample {
    public static void main(String[] args) {
        // Create a light (receiver)
        Light light = new Light();

        // Create command objects
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Create invoker object
        RemoteControl remote = new RemoteControl();

        // Issue commands through the invoker
        remote.setCommand(lightOn);
        remote.pressButton();  // Output: Light is ON

        System.out.println();

        remote.setCommand(lightOff);
        remote.pressButton();  // Output: Light is OFF
    }
}
