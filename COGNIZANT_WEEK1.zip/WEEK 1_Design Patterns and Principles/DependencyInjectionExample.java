// Step 2: Define the Repository Interface
interface CustomerRepository {
    Customer findCustomerById(int id);
}

// Step 3: Implement the Concrete Repository
class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        // For demonstration purposes, returning a dummy customer
        return new Customer(id, "John Doe");
    }
}

// Step 4: Define the Service Class
class CustomerService {
    private final CustomerRepository customerRepository;

    // Step 5: Implement Dependency Injection using constructor injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer getCustomerById(int id) {
        return customerRepository.findCustomerById(id);
    }
}

// Define the Customer class
class Customer {
    private int id;
    private String name;

    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Customer{id=" + id + ", name='" + name + "'}";
    }
}

// Step 6: Test the Dependency Injection Implementation
public class DependencyInjectionExample {
    public static void main(String[] args) {
        // Create a CustomerRepositoryImpl instance
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject the repository into the service using constructor injection
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to find a customer
        Customer customer = customerService.getCustomerById(1);
        System.out.println(customer);
    }
}
