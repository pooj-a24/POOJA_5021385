import java.util.ArrayList;
import java.util.List;

// ObserverPatternExample.java

// Subject Interface
interface Stock {
    void registerObserver(Observer observer);
    void deregisterObserver(Observer observer);
    void notifyObservers();
}

// Concrete Subject Class
class StockMarket implements Stock {
    private List<Observer> observers = new ArrayList<>();
    private double stockPrice;

    public void setStockPrice(double price) {
        this.stockPrice = price;
        notifyObservers();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stockPrice);
        }
    }
}

// Observer Interface
interface Observer {
    void update(double price);
}

// Concrete Observer Class - MobileApp
class MobileApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("Mobile App received stock price update: $" + price);
    }
}

// Concrete Observer Class - WebApp
class WebApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("Web App received stock price update: $" + price);
    }
}

// Test Class
public class ObserverPatternExample {
    public static void main(String[] args) {
        // Create the stock market (subject)
        StockMarket stockMarket = new StockMarket();

        // Create observers
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers with the stock market
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Set stock price and notify observers
        System.out.println("Setting stock price to $100.00");
        stockMarket.setStockPrice(100.00);

        System.out.println();

        // Change stock price and notify observers
        System.out.println("Setting stock price to $120.00");
        stockMarket.setStockPrice(120.00);
    }
}
