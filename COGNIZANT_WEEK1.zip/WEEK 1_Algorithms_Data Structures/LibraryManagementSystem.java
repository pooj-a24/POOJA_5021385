public class LibraryManagementSystem {

    // Book class with attributes and a constructor
    public static class Book {
        int bookId;
        String title;
        String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }

        @Override
        public String toString() {
            return "Book{" +
                    "bookId=" + bookId +
                    ", title='" + title + '\'' +
                    ", author='" + author + '\'' +
                    '}';
        }
    }

    // Linear Search method to find books by title
    public static Book linearSearch(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary Search method to find books by title (assuming the list is sorted)
    public static Book binarySearch(Book[] books, String title, int low, int high) {
        if (low <= high) {
            int mid = (low + high) / 2;
            int cmp = books[mid].title.compareToIgnoreCase(title);

            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                return binarySearch(books, title, mid + 1, high);
            } else {
                return binarySearch(books, title, low, mid - 1);
            }
        }
        return null;
    }

    // Main method to run the program
    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Java Programming", "Priya"),
            new Book(2, "Data Structures", "Akshay"),
            new Book(3, "Algorithm Design", "Tanya"),
            new Book(4, "Database Systems", "Meera")
        };

        // Sort the books array by title for binary search
        java.util.Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        // Linear Search
        String searchTitle = "Data Structures";
        Book foundBook = linearSearch(books, searchTitle);
        System.out.println("Linear Search result for '" + searchTitle + "': " + (foundBook != null ? foundBook : "Book not found"));

        // Binary Search
        foundBook = binarySearch(books, searchTitle, 0, books.length - 1);
        System.out.println("Binary Search result for '" + searchTitle + "': " + (foundBook != null ? foundBook : "Book not found"));
    }
}

