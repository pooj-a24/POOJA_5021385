import java.util.Scanner;

// Define the FinancialForecasting class
public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double initialValue, double growthRate, int years) {
        // Base case: If years is 0, return the initial value
        if (years == 0) {
            return initialValue;
        }
        // Recursive case: Calculate the future value for one year less and apply the growth rate
        return calculateFutureValue(initialValue, growthRate, years - 1) * (1 + growthRate);
    }

    // Main method to test the recursive future value calculation
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input for initial value
        System.out.print("Enter the initial value: ");
        double initialValue = scanner.nextDouble();

        // Get user input for growth rate
        System.out.print("Enter the growth rate (as a decimal, e.g., 0.05 for 5%): ");
        double growthRate = scanner.nextDouble();

        // Get user input for number of years
        System.out.print("Enter the number of years: ");
        int years = scanner.nextInt();

        // Calculate the future value
        double futureValue = calculateFutureValue(initialValue, growthRate, years);

        // Display the result
        System.out.printf("The future value after %d years is: %.2f%n", years, futureValue);

        // Close the scanner
        scanner.close();
    }
}

